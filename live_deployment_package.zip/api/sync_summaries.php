<?php
// Emergency Sync Script for HRMS
// Run this directly in the browser to fix missing Daily Summaries
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db.php';
require_once 'attendance.php'; // For updateDailySummary

$database = new Database();
$db = $database->getConnection();

echo "<h1>HRMS Attendance Sync</h1>";

try {
    $today = date('Y-m-d');
    
    // 1. First, check if the SQL tables have the correct AUTO_INCREMENT structure
    $stmt = $db->query("SHOW CREATE TABLE daily_attendance_summary");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if (strpos($result['Create Table'], 'AUTO_INCREMENT') === false) {
        echo "<p style='color:red;'>⚠️ WARNING: Your daily_attendance_summary table is missing AUTO_INCREMENT! The sync might fail.</p>";
    }

    echo "<p>Syncing attendance for today: <strong>$today</strong></p>";

    // 2. Get all unique employees who have attendance entries today
    $stmt = $db->prepare("SELECT DISTINCT employee_id, employee_name FROM attendance WHERE date = :today");
    $stmt->bindParam(':today', $today);
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($employees)) {
        echo "<p>No one has clocked in today yet.</p>";
        exit;
    }

    $synced = 0;
    foreach ($employees as $emp) {
        echo "Updating summary for: " . htmlspecialchars($emp['employee_name']) . " (ID: {$emp['employee_id']})<br>";
        
        // This function exists in attendance.php and calculates total hours and status
        updateDailySummary($db, $emp['employee_id'], $emp['employee_name'], $today);
        $synced++;
    }
    
    echo "<br><h3 style='color:green;'>✅ Success! Synced summaries for $synced employee(s).</h3>";
    echo "<p>You can now check the Admin Dashboard. If numbers still show 0, your database is missing AUTO_INCREMENT IDs.</p>";

} catch (PDOException $e) {
    echo "<br><h3 style='color:red;'>❌ Database Error:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
} catch (Exception $e) {
    echo "<br><h3 style='color:red;'>❌ General Error:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
